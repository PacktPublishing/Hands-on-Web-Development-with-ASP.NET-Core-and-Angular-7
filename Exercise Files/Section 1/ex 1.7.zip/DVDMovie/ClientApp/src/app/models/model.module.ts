import { NgModule } from "@angular/core";
import { Repository } from "./repository";
 @NgModule({
	providers: [Repository]
})
export class ModelModule { }
